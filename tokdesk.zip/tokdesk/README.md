# TokDesk – เชื่อมบัญชี TikTok

## 1) สร้างแอป TikTok
1. ไปที่ https://developers.tiktok.com → Manage apps → Connect an app
2. เพิ่ม product **Login Kit** และเปิด scope: `user.info.basic`, `user.info.stats`, `video.list`
3. ช่อง **Redirect URI** ใส่: `https://<โดเมนของคุณ>/auth/tiktok/callback` (ต้องตรงเป๊ะ)
4. ระหว่างยังไม่ผ่านรีวิว (Sandbox) ให้เพิ่มบัญชี TikTok ของคุณเป็น **Target/Test user**
5. คัดลอก Client Key / Client Secret

## 2) Deploy (ตัวอย่าง Render – ฟรี)
1. push โฟลเดอร์นี้ขึ้น GitHub repo ใหม่
2. Render → New → Web Service → เลือก repo
   - Build: `npm install`  Start: `npm start`
3. Environment Variables:
   - `TIKTOK_CLIENT_KEY`, `TIKTOK_CLIENT_SECRET`
   - `BASE_URL` = URL ที่ Render ให้ (เช่น `https://tokdesk.onrender.com`)
4. เอา URL นั้นไปใส่เป็น Redirect URI ที่ TikTok (ข้อ 1.3) แล้วเปิดเว็บผ่าน URL นี้ **ไม่ใช่ github.io**

## รันในเครื่อง
```
npm install
cp .env.example .env   # แก้ค่า
node --env-file=.env server.js
```
TikTok ไม่รับ `http://localhost` เป็น redirect บางกรณี ให้ใช้ ngrok/cloudflared แล้วตั้ง BASE_URL เป็น URL นั้น
