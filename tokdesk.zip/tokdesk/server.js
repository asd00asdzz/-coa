import express from "express";
import crypto from "node:crypto";

const { TIKTOK_CLIENT_KEY, TIKTOK_CLIENT_SECRET, BASE_URL = "http://localhost:3000" } = process.env;
const REDIRECT_URI = `${BASE_URL}/auth/tiktok/callback`;
const PORT = process.env.PORT || 3000;
const SECURE = BASE_URL.startsWith("https://");

if (!TIKTOK_CLIENT_KEY || !TIKTOK_CLIENT_SECRET) {
  console.warn("⚠️  ยังไม่ได้ตั้ง TIKTOK_CLIENT_KEY / TIKTOK_CLIENT_SECRET");
}

const app = express();
app.set("trust proxy", 1);

// ---------- session แบบง่าย (เก็บในหน่วยความจำ) ----------
// หมายเหตุ: รีสตาร์ทเซิร์ฟเวอร์แล้วต้องเชื่อมใหม่ ถ้าจะใช้จริงจังให้เปลี่ยนเป็น Redis/DB
const sessions = new Map();

function parseCookies(req) {
  return Object.fromEntries(
    (req.headers.cookie || "").split(";").map((c) => c.trim().split("=")).filter((p) => p[0])
  );
}
function getSession(req, res) {
  let sid = parseCookies(req).sid;
  if (!sid || !sessions.has(sid)) {
    sid = crypto.randomBytes(24).toString("hex");
    sessions.set(sid, {});
    res.append(
      "Set-Cookie",
      `sid=${sid}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000${SECURE ? "; Secure" : ""}`
    );
  }
  return sessions.get(sid);
}
app.use((req, res, next) => { req.session = getSession(req, res); next(); });

// ---------- TikTok helpers ----------
async function tokenRequest(params) {
  const r = await fetch("https://open.tiktokapis.com/v2/oauth/token/", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_key: TIKTOK_CLIENT_KEY,
      client_secret: TIKTOK_CLIENT_SECRET,
      ...params,
    }),
  });
  const data = await r.json();
  if (!r.ok || data.error) throw new Error(data.error_description || data.error || "token error");
  return data;
}

function saveToken(session, t) {
  session.token = {
    access_token: t.access_token,
    refresh_token: t.refresh_token,
    expires_at: Date.now() + (t.expires_in - 60) * 1000,
  };
}

async function accessToken(session) {
  const t = session.token;
  if (!t) return null;
  if (Date.now() > t.expires_at && t.refresh_token) {
    saveToken(session, await tokenRequest({ grant_type: "refresh_token", refresh_token: t.refresh_token }));
  }
  return session.token.access_token;
}

async function tiktok(session, url, options = {}) {
  const token = await accessToken(session);
  if (!token) throw Object.assign(new Error("not connected"), { status: 401 });
  const r = await fetch(url, {
    ...options,
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", ...options.headers },
  });
  const data = await r.json();
  if (data.error?.code && data.error.code !== "ok") {
    throw Object.assign(new Error(data.error.message || data.error.code), { status: r.status });
  }
  return data.data;
}

// ---------- OAuth ----------
app.get("/auth/tiktok", (req, res) => {
  if (!TIKTOK_CLIENT_KEY) return res.status(500).send("ยังไม่ได้ตั้งค่า TIKTOK_CLIENT_KEY บนเซิร์ฟเวอร์");
  const state = crypto.randomBytes(16).toString("hex");
  req.session.state = state;
  const params = new URLSearchParams({
    client_key: TIKTOK_CLIENT_KEY,
    scope: "user.info.basic,user.info.stats,video.list",
    response_type: "code",
    redirect_uri: REDIRECT_URI,
    state,
  });
  res.redirect(`https://www.tiktok.com/v2/auth/authorize/?${params}`);
});

app.get("/auth/tiktok/callback", async (req, res) => {
  const { code, state, error, error_description } = req.query;
  if (error) return res.redirect(`/?error=${encodeURIComponent(error_description || error)}`);
  if (!code || !state || state !== req.session.state) {
    return res.redirect("/?error=" + encodeURIComponent("state ไม่ตรง ลองเชื่อมใหม่อีกครั้ง"));
  }
  delete req.session.state;
  try {
    saveToken(req.session, await tokenRequest({
      code: decodeURIComponent(code),
      grant_type: "authorization_code",
      redirect_uri: REDIRECT_URI,
    }));
    res.redirect("/?connected=1");
  } catch (e) {
    res.redirect(`/?error=${encodeURIComponent(e.message)}`);
  }
});

app.post("/auth/logout", (req, res) => {
  delete req.session.token;
  res.json({ ok: true });
});

// ---------- API ให้หน้าเว็บเรียก ----------
app.get("/api/status", (req, res) => res.json({ connected: !!req.session.token }));

app.get("/api/me", async (req, res) => {
  try {
    const fields = "open_id,avatar_url,display_name,follower_count,following_count,likes_count,video_count";
    const data = await tiktok(req.session, `https://open.tiktokapis.com/v2/user/info/?fields=${fields}`);
    res.json(data.user);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

app.get("/api/videos", async (req, res) => {
  try {
    const fields = "id,title,cover_image_url,share_url,create_time,view_count,like_count,comment_count,share_count";
    const data = await tiktok(req.session, `https://open.tiktokapis.com/v2/video/list/?fields=${fields}`, {
      method: "POST",
      body: JSON.stringify({ max_count: 20 }),
    });
    res.json(data.videos || []);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

app.use(express.static("public"));
app.listen(PORT, () => console.log(`TokDesk รันที่ ${BASE_URL} (port ${PORT})`));
